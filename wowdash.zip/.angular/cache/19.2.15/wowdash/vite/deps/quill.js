import {
  Range,
  import_quill_delta,
  module_default,
  parchment_exports,
  quill_default
} from "./chunk-5LYUSQQQ.js";
import "./chunk-S35DAJRX.js";
var export_AttributeMap = import_quill_delta.AttributeMap;
var export_Delta = import_quill_delta.default;
var export_Op = import_quill_delta.Op;
var export_OpIterator = import_quill_delta.OpIterator;
export {
  export_AttributeMap as AttributeMap,
  export_Delta as Delta,
  module_default as Module,
  export_Op as Op,
  export_OpIterator as OpIterator,
  parchment_exports as Parchment,
  Range,
  quill_default as default
};
